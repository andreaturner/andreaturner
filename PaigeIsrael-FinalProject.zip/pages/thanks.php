<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Mail acknowledgment</title>
        <link rel="stylesheet" href="../styles/style.css"/>
    </head>

    <body>
        <br>
        
        <div class="header-text-blue">
            Thank You!    
        </div>
        <div class="header-small-text-green">
            Thank you submitting the contact form. I'll be in touch soon!.
        </div>  
    </body>
</html>